import { MasterResume, TailoredResume } from '../types/resume';
import { INITIAL_SAMPLE_MASTER_RESUME } from '../services/sampleData';

const MASTER_STORAGE_KEY = 'omnibase_master_resume_v1';
const TAILORED_HISTORY_KEY = 'omnibase_tailored_history_v1';

export function normalizeMasterResume(data: any): MasterResume {
  const base = INITIAL_SAMPLE_MASTER_RESUME;
  if (!data) return base;

  // Detect and purge old demo persona (e.g. Alex Vance, OmniCloud, Carnegie Mellon demo)
  const isOldDemoPersona =
    data.contact?.fullName === 'Alex Vance, M.S.' ||
    data.contact?.email === 'alex.vance.dev@example.com' ||
    (Array.isArray(data.experiences) &&
      data.experiences.some((exp: any) => exp.company?.includes('OmniCloud') || exp.company?.includes('Helix')));

  if (isOldDemoPersona) {
    // Return pure genuine truth document without any demo data
    return base;
  }

  return {
    id: data.id || base.id,
    version: data.version || 1,
    lastUpdated: data.lastUpdated || new Date().toISOString(),
    contact: {
      fullName: data.contact?.fullName || base.contact.fullName,
      headline: data.contact?.headline || base.contact.headline,
      email: data.contact?.email && data.contact.email !== 'lfrohling@gmail.com' ? data.contact.email : base.contact.email,
      phone: data.contact?.phone ?? base.contact.phone,
      location: data.contact?.location || base.contact.location,
      residentialAddress: data.contact?.residentialAddress || base.contact.residentialAddress,
      currentStatus: data.contact?.currentStatus || base.contact.currentStatus,
      relocationDetails: data.contact?.relocationDetails || base.contact.relocationDetails,
      linkedin: data.contact?.linkedin || base.contact.linkedin,
      github: data.contact?.github ?? '',
      website: data.contact?.website && !data.contact.website.includes('ai.studio') ? data.contact.website : base.contact.website,
    },
    executiveSummaries: Array.isArray(data.executiveSummaries) && data.executiveSummaries.length > 0
      ? data.executiveSummaries
          .filter((s: any) => !s.text?.includes('Series B through IPO') && !s.text?.includes('28 engineers across 4 squads'))
          .map((s: any, idx: number) => ({
            id: s.id || `sum-${idx}`,
            focusTrack: s.focusTrack ?? '',
            text: s.text ?? '',
          }))
      : base.executiveSummaries,
    experiences: Array.isArray(data.experiences)
      ? data.experiences
          .filter((exp: any) => !exp.company?.includes('OmniCloud') && !exp.company?.includes('Aether') && !exp.company?.includes('Helix') && !exp.company?.includes('Nexus'))
          .map((exp: any, eIdx: number) => ({
            id: exp.id || `exp-${eIdx}`,
            company: exp.company ?? '',
            role: exp.role ?? '',
            location: exp.location ?? '',
            startDate: exp.startDate ?? '',
            endDate: exp.endDate ?? '',
            isCurrent: !!exp.isCurrent,
            summary: exp.summary ?? '',
            technologies: Array.isArray(exp.technologies) ? exp.technologies : [],
            bullets: Array.isArray(exp.bullets)
              ? exp.bullets.map((b: any, bIdx: number) => ({
                  id: b.id || `b-${eIdx}-${bIdx}`,
                  text: b.text ?? '',
                  impactMetric: b.impactMetric ?? '',
                  tags: Array.isArray(b.tags) ? b.tags : [],
                }))
              : [],
          }))
      : [],
    projects: (() => {
      const incoming: any[] = Array.isArray(data.projects)
        ? data.projects.filter((p: any) => !p.name?.includes('OmniStream') && !p.name?.includes('NeuralQuery'))
        : base.projects;
      const formatted = incoming.map((p: any, pIdx: number) => ({
        id: p.id || `proj-${pIdx}`,
        name: p.name ?? '',
        role: p.role ?? '',
        link: p.link ?? '',
        period: p.period ?? '',
        description: p.description ?? '',
        technologies: Array.isArray(p.technologies) ? p.technologies : [],
        bullets: Array.isArray(p.bullets)
          ? p.bullets.map((b: any, bIdx: number) => ({
              id: b.id || `pb-${pIdx}-${bIdx}`,
              text: b.text ?? '',
              impactMetric: b.impactMetric ?? '',
              tags: Array.isArray(b.tags) ? b.tags : [],
            }))
          : [],
      }));

      // Ensure the verified AI-Powered Customer Support Triage Agent project is present
      const hasTriage = formatted.some((p) => p.name.includes('Support Triage') || p.name.includes('Routing Agent'));
      if (!hasTriage && base.projects[0]) {
        const tp = base.projects[0];
        formatted.unshift({
          id: tp.id,
          name: tp.name,
          role: tp.role ?? '',
          link: tp.link ?? '',
          period: tp.period ?? '',
          description: tp.description,
          technologies: tp.technologies,
          bullets: tp.bullets,
        });
      }
      return formatted;
    })(),
    skillCategories: Array.isArray(data.skillCategories) && data.skillCategories.length > 0
      ? data.skillCategories.map((c: any, cIdx: number) => ({
          id: c.id || `cat-${cIdx}`,
          category: c.category ?? '',
          skills: Array.isArray(c.skills) ? c.skills : [],
        }))
      : base.skillCategories,
    education: Array.isArray(data.education)
      ? data.education.filter((edu: any) => !edu.institution?.includes('Carnegie Mellon') && !edu.institution?.includes('University of Michigan'))
      : [],
    certifications: (() => {
      const incoming: any[] = Array.isArray(data.certifications)
        ? data.certifications.filter((cert: any) => !cert.name?.includes('AWS Certified') && !cert.name?.includes('CKA') && !cert.name?.includes('Certified Kubernetes'))
        : base.certifications;

      // Ensure that all 8 Google AI courses from base are present and complete
      const googleAICourseNames = base.certifications
        .filter(c => c.id.startsWith('cert-google-ai'))
        .map(c => c.name);

      const hasAll8GoogleAI = googleAICourseNames.every(name =>
        incoming.some(c => c.name === name)
      );

      if (!hasAll8GoogleAI) {
        // Clear out old partial Google AI certifications and populate all 8 sub-courses + specialization correctly
        const nonGoogleCerts = incoming.filter(c => !c.id.startsWith('cert-google-ai'));
        const googleCerts = base.certifications.filter(c => c.id.startsWith('cert-google-ai'));
        
        // Also make sure JLPT is present
        const hasJLPT = incoming.some((c: any) => c.name?.includes('JLPT'));
        const jlpt = base.certifications.find((c) => c.name.includes('JLPT'));
        if (hasJLPT) {
          return [...googleCerts, ...nonGoogleCerts];
        } else if (jlpt) {
          return [...googleCerts, ...nonGoogleCerts, jlpt];
        }
        return [...googleCerts, ...nonGoogleCerts];
      }

      const hasJLPT = incoming.some((c: any) => c.name?.includes('JLPT'));
      if (!hasJLPT) {
        const jlpt = base.certifications.find((c) => c.name.includes('JLPT'));
        if (jlpt) incoming.push(jlpt);
      }
      return incoming;
    })(),
    additionalHighlights: Array.isArray(data.additionalHighlights)
      ? data.additionalHighlights.filter((h: string) => !h.includes('US Patent US11284902B2') && !h.includes('GopherCon') && !h.includes('Y-Combinator'))
      : base.additionalHighlights,
  };
}

export function loadMasterResume(): MasterResume {
  try {
    const raw = localStorage.getItem(MASTER_STORAGE_KEY);
    if (raw) {
      return normalizeMasterResume(JSON.parse(raw));
    }
  } catch (e) {
    console.error('Failed to load master resume from storage', e);
  }
  return INITIAL_SAMPLE_MASTER_RESUME;
}

export function saveMasterResume(resume: MasterResume): void {
  try {
    localStorage.setItem(MASTER_STORAGE_KEY, JSON.stringify(resume));
  } catch (e) {
    console.error('Failed to save master resume to storage', e);
  }
}

export function loadTailoredHistory(): TailoredResume[] {
  try {
    const raw = localStorage.getItem(TAILORED_HISTORY_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load tailored history', e);
  }
  return [];
}

export function saveTailoredHistory(history: TailoredResume[]): void {
  try {
    localStorage.setItem(TAILORED_HISTORY_KEY, JSON.stringify(history));
  } catch (e) {
    console.error('Failed to save tailored history', e);
  }
}

export async function exportResumeAsJson(resume: MasterResume): Promise<void> {
  const date = new Date().toISOString().split('T')[0];
  const filename = `master_career_dossier_${date}.json`;
  const jsonContent = JSON.stringify(resume, null, 2);

  // Modern browser File System Access API (allows picking exact directory / folder)
  if ('showSaveFilePicker' in window) {
    try {
      const handle = await (window as any).showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: 'JSON Career Dossier',
            accept: { 'application/json': ['.json'] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(jsonContent);
      await writable.close();
      return;
    } catch (err: any) {
      if (err.name === 'AbortError') return; // User canceled the picker
      console.warn('File picker failed, falling back to download anchor', err);
    }
  }

  // Fallback for standard browser download behavior
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(jsonContent);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', filename);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export async function exportAsMarkdownFile(content: string, filename: string): Promise<void> {
  // Modern browser File System Access API (allows choosing exact folder in C:\Storage\...)
  if ('showSaveFilePicker' in window) {
    try {
      const handle = await (window as any).showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: 'Markdown Document',
            accept: { 'text/markdown': ['.md'] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(content);
      await writable.close();
      return;
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      console.warn('File picker failed, falling back to download anchor', err);
    }
  }

  const dataStr = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(content);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', filename);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

/**
 * Generates an exhaustive, beautifully formatted plain text (*.txt) representation of the entire Master Career Dossier.
 */
export function formatMasterResumeAsPlainText(resume: MasterResume): string {
  const lines: string[] = [];
  const divider = '='.repeat(80);
  const subDivider = '-'.repeat(80);

  lines.push(divider);
  lines.push(`MASTER CAREER DOSSIER (CANONICAL SOURCE OF TRUTH)`);
  lines.push(`Candidate: ${resume.contact.fullName || 'Candidate'}`);
  if (resume.contact.headline) lines.push(`Headline: ${resume.contact.headline}`);
  lines.push(`Last Synchronised / Updated: ${new Date(resume.lastUpdated || Date.now()).toLocaleString()}`);
  lines.push(divider);
  lines.push('');

  // 1. CONTACT & MOBILITY
  lines.push('1. CANDIDATE PROFILE & GLOBAL MOBILITY');
  lines.push(subDivider);
  if (resume.contact.fullName) lines.push(`Full Legal Name:        ${resume.contact.fullName}`);
  if (resume.contact.email) lines.push(`Email Address:          ${resume.contact.email}`);
  if (resume.contact.phone) lines.push(`Phone:                  ${resume.contact.phone}`);
  if (resume.contact.location) lines.push(`Public Location:        ${resume.contact.location}`);
  if (resume.contact.residentialAddress) lines.push(`Residential Address:    ${resume.contact.residentialAddress}`);
  if (resume.contact.currentStatus) lines.push(`Current Status:         ${resume.contact.currentStatus}`);
  if (resume.contact.relocationDetails) lines.push(`Relocation Details:     ${resume.contact.relocationDetails}`);
  if (resume.contact.linkedin) lines.push(`LinkedIn:               ${resume.contact.linkedin}`);
  if (resume.contact.github) lines.push(`GitHub:                 ${resume.contact.github}`);
  if (resume.contact.website) lines.push(`Portfolio / Website:    ${resume.contact.website}`);
  lines.push('');

  // 2. EXECUTIVE SUMMARIES
  if (resume.executiveSummaries && resume.executiveSummaries.length > 0) {
    lines.push('2. EXECUTIVE SUMMARIES (MULTI-TRACK PROFILES)');
    lines.push(subDivider);
    resume.executiveSummaries.forEach((s, idx) => {
      lines.push(`[Track ${idx + 1}: ${s.focusTrack || 'General Focus'}]`);
      lines.push(s.text || '');
      lines.push('');
    });
  }

  // 3. WORK EXPERIENCE
  if (resume.experiences && resume.experiences.length > 0) {
    lines.push('3. CHRONOLOGICAL WORK EXPERIENCE & HISTORICAL FOUNDATIONS');
    lines.push(subDivider);
    resume.experiences.forEach((exp, idx) => {
      lines.push(`[${idx + 1}] ${exp.role} @ ${exp.company}`);
      lines.push(`    Period:   ${exp.startDate} - ${exp.endDate || (exp.isCurrent ? 'Present' : '')}`);
      if (exp.location) lines.push(`    Location: ${exp.location}`);
      if (exp.summary) lines.push(`    Overview: ${exp.summary}`);
      if (exp.technologies && exp.technologies.length > 0) {
        lines.push(`    Technologies: ${exp.technologies.join(', ')}`);
      }
      if (exp.bullets && exp.bullets.length > 0) {
        lines.push('    Key Accomplishments & Bullet Points:');
        exp.bullets.forEach((b) => {
          const metricBadge = b.impactMetric ? ` [Metric: ${b.impactMetric}]` : '';
          const tagList = b.tags && b.tags.length > 0 ? ` (#${b.tags.join(' #')})` : '';
          lines.push(`      * ${b.text}${metricBadge}${tagList}`);
        });
      }
      lines.push('');
    });
  }

  // 4. FEATURED PROJECTS & TECHNICAL INNOVATIONS
  if (resume.projects && resume.projects.length > 0) {
    lines.push('4. KEY PROJECTS, SYSTEMS ARCHITECTURE & AGENT DEPLOYMENTS');
    lines.push(subDivider);
    resume.projects.forEach((proj, idx) => {
      lines.push(`[Project ${idx + 1}] ${proj.name}`);
      if (proj.role) lines.push(`    Role:         ${proj.role}`);
      if (proj.period) lines.push(`    Period:       ${proj.period}`);
      if (proj.link) lines.push(`    Link / URL:   ${proj.link}`);
      if (proj.description) lines.push(`    Overview:     ${proj.description}`);
      if (proj.technologies && proj.technologies.length > 0) {
        lines.push(`    Tech Stack:   ${proj.technologies.join(', ')}`);
      }
      if (proj.bullets && proj.bullets.length > 0) {
        lines.push('    Technical Deliverables & XYZ Formula Metrics:');
        proj.bullets.forEach((b) => {
          const metricBadge = b.impactMetric ? ` [Metric: ${b.impactMetric}]` : '';
          lines.push(`      * ${b.text}${metricBadge}`);
        });
      }
      lines.push('');
    });
  }

  // 5. SKILLS TAXONOMY & OPERATING FRAMEWORKS
  if (resume.skillCategories && resume.skillCategories.length > 0) {
    lines.push('5. SKILLS TAXONOMY, FRAMEWORKS & COMPETENCIES');
    lines.push(subDivider);
    resume.skillCategories.forEach((cat) => {
      lines.push(`* ${cat.category}:`);
      lines.push(`    ${cat.skills.join(' • ')}`);
      lines.push('');
    });
  }

  // 6. EDUCATION
  if (resume.education && resume.education.length > 0) {
    lines.push('6. FORMAL EDUCATION');
    lines.push(subDivider);
    resume.education.forEach((edu) => {
      lines.push(`* ${edu.degree} in ${edu.fieldOfStudy}`);
      lines.push(`    Institution: ${edu.institution} (${edu.graduationYear})`);
      if (edu.location) lines.push(`    Location:    ${edu.location}`);
      if (edu.honors) lines.push(`    Honours:     ${edu.honors}`);
      lines.push('');
    });
  }

  // 7. CERTIFICATIONS & LANGUAGE QUALIFICATIONS
  if (resume.certifications && resume.certifications.length > 0) {
    lines.push('7. CERTIFICATIONS & LANGUAGE PROFICIENCY QUALIFICATIONS');
    lines.push(subDivider);
    resume.certifications.forEach((cert) => {
      const cred = cert.credentialId ? ` (Credential ID: ${cert.credentialId})` : '';
      const urlStr = cert.url ? ` | Verification: ${cert.url}` : '';
      lines.push(`* ${cert.name} - Issued by ${cert.issuer} [${cert.date}]${cred}${urlStr}`);
    });
    lines.push('');
  }

  // 8. ADDITIONAL HIGHLIGHTS & STRATEGIC NOTES
  if (resume.additionalHighlights && resume.additionalHighlights.length > 0) {
    lines.push('8. ADDITIONAL HIGHLIGHTS, PATENTS & RECOGNITION');
    lines.push(subDivider);
    resume.additionalHighlights.forEach((highlight) => {
      lines.push(`* ${highlight}`);
    });
    lines.push('');
  }

  lines.push(divider);
  lines.push('END OF MASTER DOSSIER CANONICAL TRUTH DOCUMENT');
  lines.push(divider);

  return lines.join('\n');
}

/**
 * Triggers a download of the Master Resume as a plain text file (.txt)
 */
export async function exportResumeAsPlainText(resume: MasterResume): Promise<void> {
  const date = new Date().toISOString().split('T')[0];
  const filename = `Master_Career_Truth_Document_${date}.txt`;
  const textContent = formatMasterResumeAsPlainText(resume);

  // Modern browser File System Access API
  if ('showSaveFilePicker' in window) {
    try {
      const handle = await (window as any).showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: 'Plain Text Career Truth Document',
            accept: { 'text/plain': ['.txt'] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(textContent);
      await writable.close();
      return;
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      console.warn('File picker failed, falling back to download anchor', err);
    }
  }

  // Fallback for standard browser download behavior
  const dataStr = 'data:text/plain;charset=utf-8,' + encodeURIComponent(textContent);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', filename);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}
