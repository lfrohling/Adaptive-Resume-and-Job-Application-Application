import React, { useState } from 'react';
import { Printer, Copy, Check, FileText, Sparkles, Download, LayoutTemplate } from 'lucide-react';
import { TailoredResume, MasterResume } from '../types/resume';
import { exportAsMarkdownFile } from '../utils/storage';

interface ResumeDocumentProps {
  tailoredResume?: TailoredResume | null;
  masterResume?: MasterResume;
  isMasterView?: boolean;
}

export type ResumeTheme = 'modern' | 'executive' | 'tech';

export const ResumeDocument: React.FC<ResumeDocumentProps> = ({
  tailoredResume,
  masterResume,
  isMasterView = false,
}) => {
  const [theme, setTheme] = useState<ResumeTheme>('modern');
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [activeDoc, setActiveDoc] = useState<'resume' | 'cover_letter'>('resume');

  // If viewing tailored resume, use its data; otherwise fall back to master resume summary
  const contact = masterResume?.contact || {
    fullName: 'Your Name',
    headline: 'Professional Headline',
    email: 'email@example.com',
    phone: '',
    location: '',
    linkedin: '',
    github: '',
    website: '',
  };

  const executiveSummary = tailoredResume
    ? tailoredResume.executiveSummary
    : masterResume?.executiveSummaries[0]?.text || '';

  const skillsList = tailoredResume
    ? tailoredResume.selectedSkills
    : (masterResume?.skillCategories || []).map((cat) => ({
        category: cat.category,
        skills: cat.skills,
      }));

  const experiences = tailoredResume
    ? tailoredResume.experiences
    : (masterResume?.experiences || []).map((exp) => ({
        company: exp.company,
        role: exp.role,
        location: exp.location,
        period: `${exp.startDate} - ${exp.isCurrent ? 'Present' : exp.endDate}`,
        bullets: exp.bullets.map((b) => b.text),
        technologies: exp.technologies,
      }));

  const projects = tailoredResume
    ? tailoredResume.projects
    : (masterResume?.projects || []).map((p) => ({
        name: p.name,
        role: p.role,
        period: p.period,
        bullets: p.bullets.map((b) => b.text),
        technologies: p.technologies,
      }));

  const education = tailoredResume?.education || masterResume?.education || [];
  const certifications = tailoredResume?.certifications || masterResume?.certifications || [];

  const handlePrint = () => {
    window.print();
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const generateAtsPlainText = () => {
    if (activeDoc === 'cover_letter') {
      return `${contact.fullName.toUpperCase()}\n${contact.headline}\n${[contact.email, contact.phone, contact.location, contact.linkedin].filter(Boolean).join(' | ')}\n\nTO: Hiring Manager / Recruitment Team | ${tailoredResume?.companyName || 'Hiring Organization'}\n\n${tailoredResume?.coverLetter || ''}\n\nSincerely,\n${contact.fullName}`;
    }

    let out = `${contact.fullName.toUpperCase()}\n`;
    if (contact.headline) out += `${contact.headline}\n`;
    const contactRow = [contact.email, contact.phone, contact.location, contact.linkedin, contact.github, contact.website]
      .filter(Boolean)
      .join(' | ');
    out += `${contactRow}\n\n`;

    if (executiveSummary) {
      out += `PROFESSIONAL SUMMARY\n${executiveSummary}\n\n`;
    }

    if (skillsList.length > 0) {
      out += `AREAS OF EXPERTISE & TECHNICAL SKILLS\n`;
      skillsList.forEach((cat) => {
        out += `${cat.category}: ${cat.skills.join(', ')}\n`;
      });
      out += `\n`;
    }

    if (experiences.length > 0) {
      out += `PROFESSIONAL EXPERIENCE\n`;
      experiences.forEach((exp) => {
        out += `${exp.role.toUpperCase()} | ${exp.company} (${exp.period})\n`;
        if (exp.location) out += `${exp.location}\n`;
        exp.bullets.forEach((b) => {
          out += `• ${b}\n`;
        });
        if (exp.technologies && exp.technologies.length > 0) {
          out += `Technologies: ${exp.technologies.join(', ')}\n`;
        }
        out += `\n`;
      });
    }

    if (projects.length > 0) {
      out += `KEY PROJECTS\n`;
      projects.forEach((proj) => {
        out += `${proj.name} ${proj.role ? `(${proj.role})` : ''} ${proj.period ? `[${proj.period}]` : ''}\n`;
        proj.bullets.forEach((b) => {
          out += `• ${b}\n`;
        });
        out += `\n`;
      });
    }

    if (education.length > 0) {
      out += `EDUCATION\n`;
      education.forEach((edu) => {
        out += `${edu.degree} in ${edu.fieldOfStudy} - ${edu.institution} (${edu.graduationYear})\n`;
      });
      out += `\n`;
    }

    if (certifications.length > 0) {
      out += `CERTIFICATIONS\n`;
      certifications.forEach((c) => {
        out += `${c.name} - ${c.issuer} (${c.date})\n`;
      });
    }

    return out;
  };

  const generateMarkdown = () => {
    if (activeDoc === 'cover_letter') {
      return `# Cover Letter for ${tailoredResume?.companyName || 'Hiring Organization'}\n\n**Candidate:** ${contact.fullName}\n**Role:** ${tailoredResume?.jobTitle || 'Target Position'}\n\n${tailoredResume?.coverLetter || ''}\n\nSincerely,\n\n${contact.fullName}`;
    }

    let out = `# ${contact.fullName}\n\n`;
    out += `**${contact.headline}**\n\n`;
    out += `${[contact.email, contact.phone, contact.location, contact.linkedin, contact.github, contact.website].filter(Boolean).join(' • ')}\n\n`;

    if (executiveSummary) {
      out += `## Professional Summary\n${executiveSummary}\n\n`;
    }

    if (skillsList.length > 0) {
      out += `## Core Skills\n`;
      skillsList.forEach((cat) => {
        out += `- **${cat.category}:** ${cat.skills.join(', ')}\n`;
      });
      out += `\n`;
    }

    if (experiences.length > 0) {
      out += `## Experience\n`;
      experiences.forEach((exp) => {
        out += `### ${exp.role} — ${exp.company}\n`;
        out += `*${exp.period} | ${exp.location}*\n\n`;
        exp.bullets.forEach((b) => {
          out += `- ${b}\n`;
        });
        if (exp.technologies && exp.technologies.length > 0) {
          out += `\n*Stack: ${exp.technologies.join(', ')}*\n`;
        }
        out += `\n`;
      });
    }

    if (projects.length > 0) {
      out += `## Projects\n`;
      projects.forEach((proj) => {
        out += `### ${proj.name}\n`;
        proj.bullets.forEach((b) => {
          out += `- ${b}\n`;
        });
        out += `\n`;
      });
    }

    if (education.length > 0) {
      out += `## Education\n`;
      education.forEach((edu) => {
        out += `- **${edu.degree} in ${edu.fieldOfStudy}**, ${edu.institution} (${edu.graduationYear})\n`;
      });
      out += `\n`;
    }

    return out;
  };

  // Theme-specific styling classes
  const themeClasses = {
    modern: {
      container: 'font-sans text-slate-900',
      headerName: 'text-2xl font-bold tracking-tight text-slate-950 uppercase border-b-2 border-slate-900 pb-1',
      sectionTitle: 'text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-300 pb-0.5 mt-4 mb-2 flex items-center justify-between',
      roleTitle: 'font-bold text-slate-900 text-sm',
      companyText: 'text-slate-700 font-medium text-xs',
      dateText: 'text-slate-600 text-xs font-medium',
      bulletText: 'text-xs text-slate-800 leading-relaxed',
      badge: 'bg-slate-100 text-slate-700 border border-slate-200 text-[10px] px-1.5 py-0.5 rounded',
    },
    executive: {
      container: 'font-serif text-slate-900',
      headerName: 'text-2xl font-serif font-bold tracking-wide text-slate-900 text-center border-b border-slate-400 pb-2',
      sectionTitle: 'text-xs font-serif font-bold uppercase tracking-widest text-slate-900 border-b border-slate-400 pb-0.5 mt-4 mb-2 text-center',
      roleTitle: 'font-bold text-slate-900 text-sm font-serif',
      companyText: 'italic text-slate-800 text-xs',
      dateText: 'text-slate-700 text-xs italic',
      bulletText: 'text-xs text-slate-800 leading-relaxed',
      badge: 'bg-slate-50 text-slate-800 border border-slate-300 text-[10px] px-1.5 py-0.2 rounded-sm',
    },
    tech: {
      container: 'font-sans text-slate-900',
      headerName: 'text-xl font-mono font-bold tracking-tight text-slate-950 uppercase bg-slate-100 px-2 py-1 rounded border border-slate-200',
      sectionTitle: 'text-xs font-mono font-bold uppercase tracking-wider text-indigo-900 border-b-2 border-indigo-200 pb-0.5 mt-4 mb-2',
      roleTitle: 'font-bold text-slate-900 text-sm',
      companyText: 'text-indigo-800 font-semibold text-xs',
      dateText: 'text-slate-600 text-xs font-mono',
      bulletText: 'text-xs text-slate-800 leading-relaxed',
      badge: 'bg-indigo-50 text-indigo-900 border border-indigo-200 text-[10px] px-1.5 py-0.5 rounded font-mono',
    },
  }[theme];

  return (
    <div className="flex flex-col h-full">
      {/* Control bar (hidden during print) */}
      <div className="no-print bg-slate-900/90 backdrop-blur border border-slate-800 rounded-t-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <LayoutTemplate className="w-3.5 h-3.5 text-indigo-400" />
            Style:
          </span>
          <div className="inline-flex rounded-lg bg-slate-800/90 p-0.5 border border-slate-700 text-xs">
            <button
              onClick={() => setTheme('modern')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                theme === 'modern' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Modern Clean
            </button>
            <button
              onClick={() => setTheme('executive')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                theme === 'executive' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Executive Serif
            </button>
            <button
              onClick={() => setTheme('tech')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                theme === 'tech' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tech Monospace
            </button>
          </div>
        </div>

        {tailoredResume?.coverLetter && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-slate-400">Document Type:</span>
            <div className="inline-flex rounded-lg bg-slate-800 p-0.5 border border-slate-700 text-xs">
              <button
                onClick={() => setActiveDoc('resume')}
                className={`px-3 py-1 rounded-md font-semibold transition ${
                  activeDoc === 'resume' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Tailored Resume
              </button>
              <button
                onClick={() => setActiveDoc('cover_letter')}
                className={`px-3 py-1 rounded-md font-semibold transition flex items-center gap-1.5 ${
                  activeDoc === 'cover_letter' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileText className="w-3 h-3" />
                <span>Cover Letter</span>
              </button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => copyToClipboard(generateMarkdown(), 'md')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 hover:text-white text-xs font-semibold rounded-lg border border-indigo-500/40 transition shadow-sm"
            title="Copy formatted Markdown directly into Obsidian, Word, or Google Docs"
          >
            {copiedType === 'md' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-indigo-400" />}
            {copiedType === 'md' ? 'Copied to Clipboard!' : 'Copy Markdown (Obsidian)'}
          </button>

          <button
            onClick={() => {
              const filename = `${(contact.fullName || 'Resume').replace(/\s+/g, '_')}_tailored.md`;
              exportAsMarkdownFile(generateMarkdown(), filename);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition"
            title="Download .md file directly into your Obsidian Vault folder"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Save .md</span>
          </button>

          <button
            onClick={() => copyToClipboard(generateAtsPlainText(), 'ats')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition"
            title="Copy ATS friendly raw text (optimized for Workday/Greenhouse/Taleo paste fields)"
          >
            {copiedType === 'ats' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <FileText className="w-3.5 h-3.5 text-slate-400" />}
            {copiedType === 'ats' ? 'Copied ATS Text!' : 'ATS Plain'}
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-sm transition"
            title="Print or Save to PDF with perfectly styled margins"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Outer preview scroll canvas */}
      <div className="flex-1 bg-slate-950 p-4 md:p-8 overflow-y-auto flex justify-center">
        {/* The Print Sheet Document (Standard Letter / A4 representation) */}
        <div
          id="resume-document-container"
          className={`w-full max-w-[850px] bg-white text-slate-900 shadow-2xl rounded-sm p-8 md:p-12 transition-all ${themeClasses.container}`}
          style={{ minHeight: '1050px' }}
        >
          {/* Header */}
          <header className={`mb-4 ${theme === 'executive' ? 'text-center' : ''}`}>
            <h1 className={themeClasses.headerName}>{contact.fullName || 'Candidate Name'}</h1>
            {contact.headline && (
              <p className={`text-xs font-medium text-slate-700 mt-1 ${theme === 'tech' ? 'font-mono' : ''}`}>
                {contact.headline}
              </p>
            )}
            <div
              className={`flex flex-wrap items-center gap-x-3 gap-y-1 text-slate-600 text-[11px] mt-1.5 ${
                theme === 'executive' ? 'justify-center' : ''
              }`}
            >
              {contact.email && <span>{contact.email}</span>}
              {contact.phone && <span>• {contact.phone}</span>}
              {contact.location && <span>• {contact.location}</span>}
              {contact.linkedin && <span>• {contact.linkedin}</span>}
              {contact.github && <span>• {contact.github}</span>}
              {contact.website && <span>• {contact.website}</span>}
            </div>
          </header>

          {activeDoc === 'cover_letter' ? (
            <div className="mt-8 text-xs text-slate-800 space-y-4 leading-relaxed max-w-2xl mx-auto">
              <div className="text-slate-500 font-mono text-[10px] mb-6">
                Date: {new Date(tailoredResume?.createdAt || Date.now()).toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}
              </div>
              <div className="font-bold text-slate-950 text-sm mb-4">
                To: Hiring Manager / Recruitment Team<br/>
                {tailoredResume?.companyName ? `${tailoredResume.companyName}` : 'Hiring Organization'}
              </div>
              {tailoredResume?.coverLetter ? (
                tailoredResume.coverLetter.split('\n\n').map((paragraph, pIdx) => (
                  <p key={pIdx} className="text-justify whitespace-pre-line leading-relaxed">
                    {paragraph}
                  </p>
                ))
              ) : (
                <p className="italic text-slate-400">Cover letter content generating...</p>
              )}
              <div className="pt-8">
                <p>Sincerely,</p>
                <p className="font-bold text-slate-950 text-sm mt-4">{contact.fullName}</p>
                <p className="text-slate-500 text-[10px]">{contact.headline}</p>
              </div>
            </div>
          ) : (
            <>
              {/* Professional Summary */}
              {executiveSummary && (
                <section className="print-page-break-avoid">
                  <h2 className={themeClasses.sectionTitle}>Professional Summary</h2>
                  <p className="text-xs text-slate-800 leading-relaxed text-justify">{executiveSummary}</p>
                </section>
              )}

              {/* Skills Breakdown */}
              {skillsList.length > 0 && (
                <section className="print-page-break-avoid">
                  <h2 className={themeClasses.sectionTitle}>Technical & Core Competencies</h2>
                  <div className="space-y-1.5 text-xs">
                    {skillsList.map((cat, idx) => (
                      <div key={idx} className="flex flex-wrap items-baseline gap-1.5">
                        <span className="font-bold text-slate-900 text-xs min-w-[130px]">{cat.category}:</span>
                        <span className="text-slate-800 text-xs leading-tight">{cat.skills.join(', ')}</span>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Professional Experience */}
              {experiences.length > 0 && (
                <section>
                  <h2 className={themeClasses.sectionTitle}>Professional Experience</h2>
                  <div className="space-y-4">
                    {experiences.map((exp, expIdx) => (
                      <div key={expIdx} className="print-page-break-avoid">
                        <div className="flex justify-between items-baseline">
                          <div>
                            <span className={themeClasses.roleTitle}>{exp.role}</span>
                            <span className="text-slate-600 text-xs"> — </span>
                            <span className={themeClasses.companyText}>{exp.company}</span>
                            {exp.location && <span className="text-slate-500 text-[11px]"> ({exp.location})</span>}
                          </div>
                          <span className={themeClasses.dateText}>{exp.period}</span>
                        </div>

                        <ul className="mt-1.5 space-y-1 list-disc list-outside ml-4">
                          {exp.bullets.map((bullet, bIdx) => (
                            <li key={bIdx} className={themeClasses.bulletText}>
                              {bullet}
                            </li>
                          ))}
                        </ul>

                        {exp.technologies && exp.technologies.length > 0 && (
                          <div className="mt-1.5 flex flex-wrap gap-1 items-center">
                            <span className="text-[10px] text-slate-500 font-medium">Stack:</span>
                            {exp.technologies.map((t, tIdx) => (
                              <span key={tIdx} className={themeClasses.badge}>
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Selected Projects */}
              {projects.length > 0 && (
                <section className="print-page-break-avoid">
                  <h2 className={themeClasses.sectionTitle}>Key Projects & Engineering Artifacts</h2>
                  <div className="space-y-3">
                    {projects.map((proj, pIdx) => (
                      <div key={pIdx}>
                        <div className="flex justify-between items-baseline">
                          <div>
                            <span className="font-bold text-slate-900 text-xs">{proj.name}</span>
                            {proj.role && <span className="text-slate-600 text-[11px]"> | {proj.role}</span>}
                          </div>
                          {proj.period && <span className={themeClasses.dateText}>{proj.period}</span>}
                        </div>
                        <ul className="mt-1 space-y-1 list-disc list-outside ml-4">
                          {proj.bullets.map((b, bIdx) => (
                            <li key={bIdx} className={themeClasses.bulletText}>
                              {b}
                            </li>
                          ))}
                        </ul>
                        {proj.technologies && proj.technologies.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1 items-center">
                            {proj.technologies.map((t, tIdx) => (
                              <span key={tIdx} className={themeClasses.badge}>
                                {t}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Education & Certifications */}
              {(education.length > 0 || certifications.length > 0) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 print-page-break-avoid">
                  {education.length > 0 && (
                    <section>
                      <h2 className={themeClasses.sectionTitle}>Education</h2>
                      <div className="space-y-2">
                        {education.map((edu, eIdx) => (
                          <div key={eIdx}>
                            <div className="font-bold text-slate-900 text-xs">{edu.degree}</div>
                            <div className="text-[11px] text-slate-700">{edu.fieldOfStudy}</div>
                            <div className="flex justify-between text-[11px] text-slate-600">
                              <span>{edu.institution}</span>
                              <span>{edu.graduationYear}</span>
                            </div>
                            {edu.honors && <div className="text-[10px] text-slate-500 italic">{edu.honors}</div>}
                          </div>
                        ))}
                      </div>
                    </section>
                  )}

                  {certifications.length > 0 && (
                    <section>
                      <h2 className={themeClasses.sectionTitle}>Certifications</h2>
                      <div className="space-y-1.5">
                        {certifications.map((cert, cIdx) => (
                          <div key={cIdx} className="text-xs">
                            <div className="font-semibold text-slate-900 text-xs">{cert.name}</div>
                            <div className="text-[11px] text-slate-600 flex justify-between">
                              <span>{cert.issuer}</span>
                              <span>{cert.date}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
