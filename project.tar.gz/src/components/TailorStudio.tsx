import React, { useState } from 'react';
import {
  Sparkles,
  Target,
  FileCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  TrendingUp,
  BookmarkPlus,
  Loader2,
  Sliders,
  ChevronRight,
  Zap,
  Info,
  Check,
} from 'lucide-react';
import { MasterResume, TailoredResume, HarvestSuggestion } from '../types/resume';
import { ResumeDocument } from './ResumeDocument';

interface TailorStudioProps {
  masterResume: MasterResume;
  tailoredResume: TailoredResume | null;
  onSetTailoredResume: (res: TailoredResume) => void;
  onApplyHarvestItem: (item: HarvestSuggestion) => void;
  onApplyAllHarvest: (items: HarvestSuggestion[]) => void;
  onSaveToHistory: (res: TailoredResume) => void;
  onAutoResetTruth?: () => MasterResume;
}

const SAMPLE_JOB_POSTINGS = [
  {
    title: 'Staff Distributed Systems Engineer',
    company: 'Stripe',
    description: `About the Role:
We are looking for a Staff Distributed Systems Engineer to lead the architecture of our global real-time event pipeline and settlement ledger. You will be responsible for systems processing over 500,000 requests per second with strict five-nines (99.999%) availability.

Requirements:
- 10+ years of deep hands-on experience building distributed systems in Go, Rust, or modern C++.
- Extensive production knowledge of Kafka, consensus algorithms (Raft, Paxos), and multi-region failover.
- Demonstrated experience in latency reduction (sub-50ms p99 at high volume).
- Experience leading large-scale architectural migrations from monoliths to event-driven microservices.
- Track record of mentoring staff and senior engineers and driving technical RFC standards.
- Strong knowledge of zero-trust security and SOC-2 compliance frameworks.`,
  },
  {
    title: 'Principal AI Solutions Architect',
    company: 'Anthropic / Scale AI',
    description: `Role Overview:
We are seeking a Principal AI Solutions Architect to design and deploy enterprise-scale generative AI workflows, vector search pipelines, and agentic reasoning systems for Fortune 500 clients.

Key Responsibilities:
- Architect high-throughput, low-latency RAG (Retrieval-Augmented Generation) applications integrating LLM APIs (Gemini, Claude) with vector databases (Qdrant, Pinecone).
- Design evaluation frameworks for hallucination prevention, latency budgeting, and context window optimization.
- Lead full-stack engineering initiatives using TypeScript, Next.js, Python, and cloud infrastructure (AWS/GCP).
- Partner directly with CTOs and VP of Engineering clients to craft technical roadmaps and demonstrate quantifiable business ROI.`,
  },
  {
    title: 'Engineering Director / Head of Infrastructure',
    company: 'Datadog',
    description: `Position Summary:
Lead our Core Telemetry and Cloud Infrastructure organization. You will manage 4 engineering managers and 30+ distributed systems engineers responsible for ingestion of petabytes of metric data daily.

What We Look For:
- Proven experience managing multi-team organizations (25+ engineers) in high-growth environments.
- Deep background in Kubernetes, Terraform, cloud cost optimization ($1M+ cloud savings), and developer velocity.
- Experience modernizing CI/CD pipelines to reduce cycle times from weeks to hours.
- Exceptional ability to hire, retain top engineering talent, and build engineering career ladders.`,
  },
];

export const TailorStudio: React.FC<TailorStudioProps> = ({
  masterResume,
  tailoredResume,
  onSetTailoredResume,
  onApplyHarvestItem,
  onApplyAllHarvest,
  onSaveToHistory,
  onAutoResetTruth,
}) => {
  const [jobTitle, setJobTitle] = useState(tailoredResume?.jobTitle || 'Staff Distributed Systems Engineer');
  const [companyName, setCompanyName] = useState(tailoredResume?.companyName || 'Stripe');
  const [jobPosting, setJobPosting] = useState(tailoredResume?.targetJD || SAMPLE_JOB_POSTINGS[0].description);
  const [pageBudget, setPageBudget] = useState<number>(1);
  const [emphasis, setEmphasis] = useState<'technical' | 'leadership' | 'ai_data' | 'scale'>('technical');
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'preview' | 'ats' | 'harvest'>('preview');
  const [showSuggestions, setShowSuggestions] = useState<boolean>(false);

  const handleSelectSample = (sample: typeof SAMPLE_JOB_POSTINGS[0]) => {
    setJobTitle(sample.title);
    setCompanyName(sample.company);
    setJobPosting(sample.description);
  };

  const handleGenerate = async () => {
    if (!jobPosting.trim()) {
      setErrorMsg('Please paste a job description or select a sample.');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);

    let activeMaster = masterResume;
    if (onAutoResetTruth) {
      activeMaster = onAutoResetTruth();
    }

    try {
      const response = await fetch('/api/gemini/tailor-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          masterResume: activeMaster,
          jobPosting,
          jobTitle,
          companyName,
          pageBudget,
          tone: emphasis,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Failed to tailor resume');
      }

      const data: TailoredResume = await response.json();
      onSetTailoredResume(data);
      onSaveToHistory(data);
      setActiveView('preview');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error communicating with Gemini');
    } finally {
      setIsGenerating(false);
    }
  };

  const unappliedHarvests = (tailoredResume?.harvestedInsights || []).filter((h) => !h.applied);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Configuration & Prompt Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Job Description & Controls */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-indigo-400" />
              <h2 className="font-bold text-white text-base">Target Opportunity</h2>
            </div>
            <span className="text-xs text-indigo-400 font-medium bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
              Propagate from Master
            </span>
          </div>

          {/* Quick sample chips */}
          <div>
            <label className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              Quick Test with Sample Job Descriptions:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_JOB_POSTINGS.map((sample, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectSample(sample)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition text-left ${
                    jobTitle === sample.title
                      ? 'bg-indigo-600/30 text-indigo-200 border-indigo-500/50'
                      : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700'
                  }`}
                >
                  {sample.company} ({sample.title.split(' ')[0]})
                </button>
              ))}
            </div>
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Target Job Title</label>
              <input
                type="text"
                value={jobTitle ?? ''}
                onChange={(e) => setJobTitle(e.target.value)}
                placeholder="e.g. Staff Software Engineer"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Company / Organization</label>
              <input
                type="text"
                value={companyName ?? ''}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g. Stripe"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-slate-400">Paste Full Job Description / Posting</label>
              <span className="text-[10px] text-slate-500">{(jobPosting ?? '').length} characters</span>
            </div>
            <textarea
              rows={8}
              value={jobPosting ?? ''}
              onChange={(e) => setJobPosting(e.target.value)}
              placeholder="Paste the target job description, responsibilities, requirements, and tech stack here..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 leading-relaxed font-mono placeholder-slate-600 focus:outline-none focus:border-indigo-500 resize-y"
            />
          </div>

          {/* Configuration switches */}
          <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-800">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Page Constraint</label>
              <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setPageBudget(1)}
                  className={`py-1 rounded font-medium transition ${
                    pageBudget === 1 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  1-Page (Dense)
                </button>
                <button
                  type="button"
                  onClick={() => setPageBudget(2)}
                  className={`py-1 rounded font-medium transition ${
                    pageBudget === 2 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  2-Page (Deep)
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Focus Emphasis</label>
              <select
                value={emphasis}
                onChange={(e: any) => setEmphasis(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="technical">Technical Depth & Architecture</option>
                <option value="leadership">Management & Velocity</option>
                <option value="ai_data">AI & Data Engineering</option>
                <option value="scale">Extreme Concurrency & Scale</option>
              </select>
            </div>
          </div>

          {/* Suggestions feedback toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <div>
              <span className="text-slate-300 font-medium block">Show AI Harvesting Suggestions</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Prompt to enrich master base upon completion</span>
            </div>
            <button
              type="button"
              onClick={() => setShowSuggestions(!showSuggestions)}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                showSuggestions ? 'bg-indigo-600' : 'bg-slate-800'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  showSuggestions ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition disabled:opacity-60 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Synthesizing Targeted Resume with Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Propagate & Tailor Resume</span>
              </>
            )}
          </button>
        </div>

        {/* Right Output: Scorecard & View Selector */}
        <div className="lg:col-span-7 space-y-4">
          {tailoredResume ? (
            <>
              {/* ATS Match Scorecard Banner */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-4">
                    {/* Circular Score Gauge */}
                    <div className="relative w-16 h-16 flex items-center justify-center rounded-2xl bg-indigo-950 border border-indigo-500/30">
                      <span className="text-xl font-black text-cyan-400">
                        {tailoredResume.atsAnalysis?.matchScore ?? 92}%
                      </span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-white text-base">ATS Keyword & Role Fit Score</h3>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                          Optimized
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 line-clamp-2">
                        {tailoredResume.atsAnalysis?.roleFitSummary}
                      </p>
                    </div>
                  </div>

                  {/* View Switcher */}
                  <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs shrink-0">
                    <button
                      onClick={() => setActiveView('preview')}
                      className={`px-3 py-1.5 rounded-lg font-medium transition ${
                        activeView === 'preview'
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Print-Ready PDF
                    </button>
                    <button
                      onClick={() => setActiveView('ats')}
                      className={`px-3 py-1.5 rounded-lg font-medium transition ${
                        activeView === 'ats'
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Keywords ({tailoredResume.atsAnalysis?.matchedKeywords.length || 0})
                    </button>
                    {showSuggestions && unappliedHarvests.length > 0 && (
                      <button
                        onClick={() => setActiveView('harvest')}
                        className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                          activeView === 'harvest'
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'text-emerald-400 hover:text-emerald-300 bg-emerald-950/30 border border-emerald-800/40'
                        }`}
                      >
                        <Zap className="w-3 h-3 text-emerald-400" />
                        <span>Harvest ({unappliedHarvests.length})</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Sub-strip: Harvest Alert if any unapplied */}
                {showSuggestions && unappliedHarvests.length > 0 && (
                  <div className="mt-4 p-3 bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/40 rounded-xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 text-xs text-emerald-200">
                      <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        <strong>Feedback Loop:</strong> Gemini synthesized{' '}
                        <strong>{unappliedHarvests.length} high-value new skills & refined bullets</strong> tailored for this domain.
                      </span>
                    </div>
                    <button
                      onClick={() => onApplyAllHarvest(unappliedHarvests)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shrink-0 shadow transition flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Accept & Enrich Master</span>
                    </button>
                  </div>
                )}
              </div>

              {/* View 1: ATS Keywords & Recommendations */}
              {activeView === 'ats' && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                  <div>
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Matched Keywords in Resume ({tailoredResume.atsAnalysis?.matchedKeywords.length})
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {tailoredResume.atsAnalysis?.matchedKeywords.map((kw, i) => (
                        <span
                          key={i}
                          className="text-xs bg-emerald-950/50 text-emerald-300 border border-emerald-800/60 px-2.5 py-1 rounded-md"
                        >
                          ✓ {kw}
                        </span>
                      ))}
                    </div>
                  </div>

                  {tailoredResume.atsAnalysis?.missingKeywords &&
                    tailoredResume.atsAnalysis.missingKeywords.length > 0 && (
                      <div>
                        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <AlertCircle className="w-4 h-4 text-amber-400" />
                          Recommended Gap Keywords from Job Posting ({tailoredResume.atsAnalysis?.missingKeywords.length})
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {tailoredResume.atsAnalysis.missingKeywords.map((kw, i) => (
                            <span
                              key={i}
                              className="text-xs bg-amber-950/40 text-amber-300 border border-amber-800/40 px-2.5 py-1 rounded-md"
                            >
                              + {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                  <div>
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Strategic Alignment Strengths
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {tailoredResume.atsAnalysis?.strengths.map((str, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-cyan-400 font-bold">•</span>
                          <span>{str}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                      Recommendations for Application
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-300">
                      {tailoredResume.atsAnalysis?.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-indigo-400 font-bold">•</span>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* View 2: Harvest Review Tab */}
              {activeView === 'harvest' && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                  <div className="border-b border-slate-800 pb-3">
                    <h4 className="font-bold text-white text-base">Knowledge Base Feedback Loop</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      These insights were forged during this specific job tailoring. By storing them in your Master Base, future job applications will automatically have access to these sharpened facts and skill tags.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {tailoredResume.harvestedInsights?.map((item) => (
                      <div
                        key={item.id}
                        className={`p-4 rounded-xl border transition ${
                          item.applied
                            ? 'bg-slate-950/40 border-slate-800 opacity-60'
                            : 'bg-slate-950 border-indigo-500/30'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="font-semibold text-indigo-400 uppercase tracking-wider text-[10px]">
                            {item.targetSection}
                          </span>
                          {item.applied ? (
                            <span className="text-emerald-400 font-medium flex items-center gap-1">
                              <Check className="w-3.5 h-3.5" /> Added to Master
                            </span>
                          ) : (
                            <button
                              onClick={() => onApplyHarvestItem(item)}
                              className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium transition"
                            >
                              Add to Master
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed font-medium">"{item.suggestedContent}"</p>
                        <p className="text-[11px] text-slate-400 mt-2 italic">Why: {item.reason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* View 3: Document Canvas */}
              {activeView === 'preview' && (
                <div className="rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
                  <ResumeDocument
                    tailoredResume={tailoredResume}
                    masterResume={masterResume}
                    isMasterView={false}
                  />
                </div>
              )}
            </>
          ) : (
            /* Empty State */
            <div className="h-[600px] bg-slate-900/50 border border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-indigo-950/60 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4">
                <Target className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Ready to Propagate Resume</h3>
              <p className="text-xs text-slate-400 max-w-md mb-6 leading-relaxed">
                Click <strong>"Propagate & Tailor Resume"</strong> on the left. Gemini will scan your entire Master Base, pull the most relevant facts, match the JD requirements, and generate a print-ready resume along with harvestable skills.
              </p>
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate with Stripe Sample</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
