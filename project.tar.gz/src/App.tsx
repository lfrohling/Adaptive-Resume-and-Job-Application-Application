import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MasterDossier } from './components/MasterDossier';
import { TailorStudio } from './components/TailorStudio';
import { MasterAudit } from './components/MasterAudit';
import { ApplicationsHistory } from './components/ApplicationsHistory';
import { PlatformAdvice } from './components/PlatformAdvice';
import { ImportExportModal } from './components/ImportExportModal';
import { DirectoryGuideModal } from './components/DirectoryGuideModal';
import { ActiveTab, MasterResume, TailoredResume, HarvestSuggestion } from './types/resume';
import { INITIAL_SAMPLE_MASTER_RESUME } from './services/sampleData';
import {
  loadMasterResume,
  saveMasterResume,
  loadTailoredHistory,
  saveTailoredHistory,
  exportResumeAsJson,
  exportResumeAsPlainText,
} from './utils/storage';
import { CheckCircle, Info } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('master');
  const [masterResume, setMasterResume] = useState<MasterResume>(loadMasterResume);
  const [tailoredHistory, setTailoredHistory] = useState<TailoredResume[]>(loadTailoredHistory);
  const [currentTailored, setCurrentTailored] = useState<TailoredResume | null>(() => {
    const history = loadTailoredHistory();
    return history.length > 0 ? history[0] : null;
  });
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isDirectoryGuideOpen, setIsDirectoryGuideOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auto-persist master resume on change
  useEffect(() => {
    saveMasterResume(masterResume);
  }, [masterResume]);

  // Auto-persist tailored history
  useEffect(() => {
    saveTailoredHistory(tailoredHistory);
  }, [tailoredHistory]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleUpdateMaster = (updated: MasterResume) => {
    setMasterResume(updated);
  };

  const handleResetToSample = () => {
    setMasterResume(INITIAL_SAMPLE_MASTER_RESUME);
    showToast('Restored Canonical Career Truth Document (Loaded Project 4 & New Skills)');
  };

  const handleAutoResetTruth = () => {
    setMasterResume(INITIAL_SAMPLE_MASTER_RESUME);
    return INITIAL_SAMPLE_MASTER_RESUME;
  };

  const handleImportMaster = (imported: MasterResume) => {
    setMasterResume(imported);
    setActiveTab('master');
    showToast('Successfully imported and structured Master Career Dossier!');
  };

  const handleExportJson = () => {
    exportResumeAsJson(masterResume);
    showToast('Exported Master Career Dossier as JSON backup');
  };

  const handleExportTxt = () => {
    exportResumeAsPlainText(masterResume);
    showToast('Exported Master Truth Document as readable *.txt');
  };

  const handleSaveToHistory = (newTailored: TailoredResume) => {
    setTailoredHistory((prev) => {
      const filtered = prev.filter((item) => item.id !== newTailored.id);
      return [newTailored, ...filtered];
    });
  };

  const handleDeleteHistory = (id: string) => {
    setTailoredHistory((prev) => prev.filter((item) => item.id !== id));
    if (currentTailored?.id === id) {
      setCurrentTailored(null);
    }
    showToast('Removed tailored resume from archive');
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear all saved tailored resumes?')) {
      setTailoredHistory([]);
      setCurrentTailored(null);
      showToast('Cleared tailored application history');
    }
  };

  // BI-DIRECTIONAL KNOWLEDGE HARVESTING
  const handleApplyHarvestItem = (item: HarvestSuggestion) => {
    let updated = { ...masterResume };

    if (item.type === 'new_skill') {
      // Find suitable category or default to first
      const cat = updated.skillCategories[0];
      if (cat && !cat.skills.includes(item.suggestedContent)) {
        cat.skills.push(item.suggestedContent);
      }
    } else if (item.type === 'enhanced_bullet' || item.type === 'new_achievement') {
      // Add to latest experience
      if (updated.experiences.length > 0) {
        updated.experiences[0].bullets.push({
          id: `b-harvest-${Date.now()}`,
          text: item.suggestedContent,
          impactMetric: 'Newly Harvested Impact',
          tags: ['Harvested'],
        });
      }
    } else if (item.type === 'summary_variant') {
      updated.executiveSummaries.push({
        id: `sum-harvest-${Date.now()}`,
        focusTrack: 'Harvested Focus Track',
        text: item.suggestedContent,
      });
    }

    setMasterResume(updated);

    // Mark as applied in current tailored resume
    if (currentTailored) {
      const updatedTailored = {
        ...currentTailored,
        harvestedInsights: currentTailored.harvestedInsights?.map((h) =>
          h.id === item.id ? { ...h, applied: true } : h
        ),
      };
      setCurrentTailored(updatedTailored);
      handleSaveToHistory(updatedTailored);
    }

    showToast(`Harvested into Master Base: "${item.suggestedContent.slice(0, 38)}..."`);
  };

  const handleApplyAllHarvest = (items: HarvestSuggestion[]) => {
    let updated = { ...masterResume };

    items.forEach((item) => {
      if (item.type === 'new_skill') {
        const cat = updated.skillCategories[0];
        if (cat && !cat.skills.includes(item.suggestedContent)) {
          cat.skills.push(item.suggestedContent);
        }
      } else {
        if (updated.experiences.length > 0) {
          updated.experiences[0].bullets.push({
            id: `b-harvest-${Math.random()}`,
            text: item.suggestedContent,
            impactMetric: 'Harvested Metric',
            tags: ['Harvested'],
          });
        }
      }
    });

    setMasterResume(updated);

    if (currentTailored) {
      const updatedTailored = {
        ...currentTailored,
        harvestedInsights: currentTailored.harvestedInsights?.map((h) => ({ ...h, applied: true })),
      };
      setCurrentTailored(updatedTailored);
      handleSaveToHistory(updatedTailored);
    }

    showToast(`Harvested all ${items.length} new insights into Master Base!`);
  };

  const unappliedCount = (currentTailored?.harvestedInsights || []).filter((h) => !h.applied).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* App Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        masterResume={masterResume}
        hasTailoredResume={!!currentTailored}
        unappliedHarvestCount={unappliedCount}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onExportJson={handleExportJson}
        onExportTxt={handleExportTxt}
        onResetToSample={handleResetToSample}
        onOpenDirectoryGuide={() => setIsDirectoryGuideOpen(true)}
        history={tailoredHistory}
        onSelectResume={(res) => {
          setCurrentTailored(res);
          setActiveTab('tailor');
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'master' && (
          <MasterDossier
            masterResume={masterResume}
            onUpdateMaster={handleUpdateMaster}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onNavigateToTailor={() => setActiveTab('tailor')}
            onResetToSample={handleResetToSample}
            onExportJson={handleExportJson}
            onExportTxt={handleExportTxt}
          />
        )}

        {activeTab === 'tailor' && (
          <TailorStudio
            masterResume={masterResume}
            tailoredResume={currentTailored}
            onSetTailoredResume={(res) => setCurrentTailored(res)}
            onApplyHarvestItem={handleApplyHarvestItem}
            onApplyAllHarvest={handleApplyAllHarvest}
            onSaveToHistory={handleSaveToHistory}
            onAutoResetTruth={handleAutoResetTruth}
          />
        )}

        {activeTab === 'audit' && (
          <MasterAudit
            masterResume={masterResume}
            onUpdateMaster={handleUpdateMaster}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'history' && (
          <ApplicationsHistory
            history={tailoredHistory}
            onSelectResume={(res) => {
              setCurrentTailored(res);
              setActiveTab('tailor');
            }}
            onDeleteResume={handleDeleteHistory}
            onClearHistory={handleClearHistory}
          />
        )}

        {activeTab === 'advice' && <PlatformAdvice />}
      </main>

      {/* Global Ingestion Modal */}
      <ImportExportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportMaster={handleImportMaster}
      />

      {/* Local Directory Guide Modal */}
      <DirectoryGuideModal
        isOpen={isDirectoryGuideOpen}
        onClose={() => setIsDirectoryGuideOpen(false)}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="no-print fixed bottom-6 right-6 z-50 bg-slate-900 border border-indigo-500/40 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
