# AI-Powered Portfolio & Automated Deployment System

This project is a high-ROI, automated career intelligence system. It acts as a single source of truth for professional experiences, engineering skills, and project metrics, allowing for the deterministic generation of tailored, ATS-optimised resumes.

## Core Features
*   **Master Career Dossier**: Centralized repository for all professional history, skills, and certifications.
*   **AI-Powered Tailoring**: Uses Gemini API to parse JD requirements and propagate tailored resumes/cover letters from the master dossier.
*   **Automated Knowledge Harvesting**: Automatically enriches the master dossier with new insights discovered during tailoring.
*   **Deployment System**: Custom Node.js/Express-based automation for secure builds and FTP production synchronization.

## Tech Stack
*   **Frontend**: React 19, TypeScript, Vite, Tailwind CSS.
*   **Backend**: Node.js, Express.
*   **AI**: Google Gemini API & Interactions SDK.
*   **DevOps**: Automated deployment pipelines, secure credential management.

## Setup
1. Clone the repository.
2. Install dependencies: `npm install`
3. Set environment variables (e.g., `GEMINI_API_KEY`).
4. Start development server: `npm run dev`
